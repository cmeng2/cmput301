package ca.ualberta.cs.lonelytwitter;

import java.util.Date;

public class SadMood extends CurrentMood {
    public boolean is_sad = true;
    //Date date = new Date();
    @Override
    public String mood() {
      //  public boolean sad = true;
        return "Sad";
    }
    public SadMood(Date date){
        this.date = new Date();
    }
        public void setDate (Date date){
            this.date = date;
        }

        public Date getDate () {
            return date;
        }

    }
