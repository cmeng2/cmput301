package ca.ualberta.cs.lonelytwitter;
import java.util.Date;

public abstract class CurrentMood {
    Date date = new Date();
    public abstract String mood();
    public CurrentMood(){
        SadMood a = new SadMood(date);
        if (a.is_sad){
            System.out.println("Sad right now.");
        }
        LonelyMood b = new LonelyMood(date);
        if (b.is_lonely){
            System.out.println("Lonely right now.");
        }
    }

}
