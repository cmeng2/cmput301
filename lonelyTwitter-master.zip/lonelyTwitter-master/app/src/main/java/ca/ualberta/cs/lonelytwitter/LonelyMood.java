package ca.ualberta.cs.lonelytwitter;
import java.util.Date;
public class LonelyMood extends CurrentMood {
    public boolean is_lonely = true;

    @Override
    public String mood() {
       // boolean lonely = true;
        return "Lonely";
    }

    public LonelyMood(Date date){
        this.date = new Date();
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}

